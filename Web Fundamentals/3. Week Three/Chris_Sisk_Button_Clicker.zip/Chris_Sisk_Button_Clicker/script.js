function loginButtonSwitch(id){
    id.value="Logout";
}

function addDefinitionDisappear(element){
    element.remove();
}