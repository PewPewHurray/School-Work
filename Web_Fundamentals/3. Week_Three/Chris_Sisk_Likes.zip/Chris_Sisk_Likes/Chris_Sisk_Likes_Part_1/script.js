function addLike(id){
    var element = document.querySelector(id);
    element.innerHTML++
}